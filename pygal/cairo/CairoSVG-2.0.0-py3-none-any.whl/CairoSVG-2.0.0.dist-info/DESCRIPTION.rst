
CairoSVG - A Simple SVG Converter Based on Cairo
================================================

CairoSVG is a SVG converter based on Cairo. It can convert SVG files to PDF,
PostScript and PNG files.

For further information, please visit the `CairoSVG Website
<http://cairosvg.org/>`_.



